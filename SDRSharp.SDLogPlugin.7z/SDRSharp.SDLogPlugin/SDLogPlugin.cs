﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SDRSharp.Common;

namespace SDRSharp.SDLogPlugin
{
    public class SDLogPlugin : ISharpPlugin
    {
        private readonly string _displayName = Utils.APP_CAPTION + " " + Utils.Version();
        private ISharpControl _control;
        private SDLogPluginPanel _guiControl;

        public UserControl Gui
        {
            get { return _guiControl; }
        }

        public string DisplayName
        {
            get { return _displayName; }
        }

        public void Close()
        {
            _guiControl.Close();
        }

        public void Initialize(ISharpControl control)
        {
            _control = control;
            _guiControl = new SDLogPluginPanel(control);
        }
    }
}
