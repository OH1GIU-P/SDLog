﻿namespace SDRSharp.SDLogPlugin
{
    partial class SDLogPluginPanel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonStart = new System.Windows.Forms.Button();
            this.buttonStop = new System.Windows.Forms.Button();
            this.timerSDLog = new System.Windows.Forms.Timer(this.components);
            this.groupBoxOperator = new System.Windows.Forms.GroupBox();
            this.radioButtonGT = new System.Windows.Forms.RadioButton();
            this.radioButtonLT = new System.Windows.Forms.RadioButton();
            this.labelLogFile = new System.Windows.Forms.Label();
            this.labelLat = new System.Windows.Forms.Label();
            this.labelLon = new System.Windows.Forms.Label();
            this.labelStatus = new System.Windows.Forms.Label();
            this.numericUpDownThresh = new System.Windows.Forms.NumericUpDown();
            this.labelThresh = new System.Windows.Forms.Label();
            this.labelThresh2 = new System.Windows.Forms.Label();
            this.groupBoxOperator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownThresh)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonStart
            // 
            this.buttonStart.Location = new System.Drawing.Point(13, 15);
            this.buttonStart.Name = "buttonStart";
            this.buttonStart.Size = new System.Drawing.Size(75, 23);
            this.buttonStart.TabIndex = 0;
            this.buttonStart.Text = "Start";
            this.buttonStart.UseVisualStyleBackColor = true;
            this.buttonStart.Click += new System.EventHandler(this.ButtonStart_Click);
            // 
            // buttonStop
            // 
            this.buttonStop.Enabled = false;
            this.buttonStop.Location = new System.Drawing.Point(119, 15);
            this.buttonStop.Name = "buttonStop";
            this.buttonStop.Size = new System.Drawing.Size(75, 23);
            this.buttonStop.TabIndex = 1;
            this.buttonStop.Text = "Stop";
            this.buttonStop.UseVisualStyleBackColor = true;
            this.buttonStop.Click += new System.EventHandler(this.ButtonStop_Click);
            // 
            // timerSDLog
            // 
            this.timerSDLog.Interval = 250;
            this.timerSDLog.Tick += new System.EventHandler(this.timerSDLog_Tick);
            // 
            // groupBoxOperator
            // 
            this.groupBoxOperator.Controls.Add(this.radioButtonGT);
            this.groupBoxOperator.Controls.Add(this.radioButtonLT);
            this.groupBoxOperator.Location = new System.Drawing.Point(13, 51);
            this.groupBoxOperator.Name = "groupBoxOperator";
            this.groupBoxOperator.Size = new System.Drawing.Size(63, 72);
            this.groupBoxOperator.TabIndex = 3;
            this.groupBoxOperator.TabStop = false;
            this.groupBoxOperator.Text = "Operator";
            // 
            // radioButtonGT
            // 
            this.radioButtonGT.AutoSize = true;
            this.radioButtonGT.Location = new System.Drawing.Point(7, 43);
            this.radioButtonGT.Name = "radioButtonGT";
            this.radioButtonGT.Size = new System.Drawing.Size(31, 17);
            this.radioButtonGT.TabIndex = 1;
            this.radioButtonGT.TabStop = true;
            this.radioButtonGT.Text = ">";
            this.radioButtonGT.UseVisualStyleBackColor = true;
            // 
            // radioButtonLT
            // 
            this.radioButtonLT.AutoSize = true;
            this.radioButtonLT.Checked = true;
            this.radioButtonLT.Location = new System.Drawing.Point(6, 19);
            this.radioButtonLT.Name = "radioButtonLT";
            this.radioButtonLT.Size = new System.Drawing.Size(31, 17);
            this.radioButtonLT.TabIndex = 0;
            this.radioButtonLT.TabStop = true;
            this.radioButtonLT.Text = "<";
            this.radioButtonLT.UseVisualStyleBackColor = true;
            // 
            // labelLogFile
            // 
            this.labelLogFile.AutoSize = true;
            this.labelLogFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLogFile.Location = new System.Drawing.Point(10, 134);
            this.labelLogFile.Name = "labelLogFile";
            this.labelLogFile.Size = new System.Drawing.Size(35, 13);
            this.labelLogFile.TabIndex = 5;
            this.labelLogFile.Text = "label1";
            // 
            // labelLat
            // 
            this.labelLat.AutoSize = true;
            this.labelLat.Location = new System.Drawing.Point(10, 156);
            this.labelLat.Name = "labelLat";
            this.labelLat.Size = new System.Drawing.Size(35, 13);
            this.labelLat.TabIndex = 6;
            this.labelLat.Text = "label1";
            // 
            // labelLon
            // 
            this.labelLon.AutoSize = true;
            this.labelLon.Location = new System.Drawing.Point(116, 156);
            this.labelLon.Name = "labelLon";
            this.labelLon.Size = new System.Drawing.Size(35, 13);
            this.labelLon.TabIndex = 7;
            this.labelLon.Text = "label1";
            // 
            // labelStatus
            // 
            this.labelStatus.AutoSize = true;
            this.labelStatus.Location = new System.Drawing.Point(10, 180);
            this.labelStatus.Name = "labelStatus";
            this.labelStatus.Size = new System.Drawing.Size(59, 13);
            this.labelStatus.TabIndex = 9;
            this.labelStatus.Text = "labelStatus";
            // 
            // numericUpDownThresh
            // 
            this.numericUpDownThresh.Location = new System.Drawing.Point(102, 103);
            this.numericUpDownThresh.Maximum = new decimal(new int[] {
            150,
            0,
            0,
            0});
            this.numericUpDownThresh.Minimum = new decimal(new int[] {
            150,
            0,
            0,
            -2147483648});
            this.numericUpDownThresh.Name = "numericUpDownThresh";
            this.numericUpDownThresh.Size = new System.Drawing.Size(64, 20);
            this.numericUpDownThresh.TabIndex = 10;
            this.numericUpDownThresh.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownThresh.Value = new decimal(new int[] {
            80,
            0,
            0,
            -2147483648});
            // 
            // labelThresh
            // 
            this.labelThresh.AutoSize = true;
            this.labelThresh.Location = new System.Drawing.Point(99, 56);
            this.labelThresh.Name = "labelThresh";
            this.labelThresh.Size = new System.Drawing.Size(54, 13);
            this.labelThresh.TabIndex = 11;
            this.labelThresh.Text = "Threshold";
            // 
            // labelThresh2
            // 
            this.labelThresh2.AutoSize = true;
            this.labelThresh2.Location = new System.Drawing.Point(102, 79);
            this.labelThresh2.Name = "labelThresh2";
            this.labelThresh2.Size = new System.Drawing.Size(83, 13);
            this.labelThresh2.TabIndex = 12;
            this.labelThresh2.Text = "-200 - +200 (dB)";
            // 
            // SDLogPluginPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labelThresh2);
            this.Controls.Add(this.labelThresh);
            this.Controls.Add(this.numericUpDownThresh);
            this.Controls.Add(this.labelStatus);
            this.Controls.Add(this.labelLon);
            this.Controls.Add(this.labelLat);
            this.Controls.Add(this.labelLogFile);
            this.Controls.Add(this.groupBoxOperator);
            this.Controls.Add(this.buttonStop);
            this.Controls.Add(this.buttonStart);
            this.Name = "SDLogPluginPanel";
            this.Size = new System.Drawing.Size(206, 218);
            this.groupBoxOperator.ResumeLayout(false);
            this.groupBoxOperator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownThresh)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonStart;
        private System.Windows.Forms.Button buttonStop;
        private System.Windows.Forms.Timer timerSDLog;
        private System.Windows.Forms.GroupBox groupBoxOperator;
        private System.Windows.Forms.RadioButton radioButtonLT;
        private System.Windows.Forms.RadioButton radioButtonGT;
        private System.Windows.Forms.Label labelLogFile;
        private System.Windows.Forms.Label labelLat;
        private System.Windows.Forms.Label labelLon;
        private System.Windows.Forms.Label labelStatus;
        private System.Windows.Forms.NumericUpDown numericUpDownThresh;
        private System.Windows.Forms.Label labelThresh;
        private System.Windows.Forms.Label labelThresh2;
    }
}
