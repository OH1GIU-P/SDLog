﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Device.Location;
using SDRSharp.Common;

namespace SDRSharp.SDLogPlugin
{
    public partial class SDLogPluginPanel : UserControl
    {
        private GeoCoordinateWatcher _watcher = null;
        private Control _controlSDValue = null;
        private StreamWriter _sw = null;
        private ISharpControl _sdlogplugin;
        private string _logPath = string.Empty;

        public SDLogPluginPanel(ISharpControl control)
        {
            InitializeComponent();
            _sdlogplugin = control;
            labelLogFile.Text = "";        
            labelLat.Text = "";
            labelLon.Text = "";
            labelStatus.Text = "";
            _watcher = new GeoCoordinateWatcher();
            _watcher.StatusChanged += new EventHandler<GeoPositionStatusChangedEventArgs>(watcher_StatusChanged);
            //_watcher.PositionChanged += new EventHandler<GeoPositionChangedEventArgs<GeoCoordinate>>(watcher_PositionChanged);
        }

        private void ButtonStart_Click(object sender, EventArgs e)
        {
            labelLat.Text = "";
            labelLon.Text = "";
            if (!_watcher.TryStart(false, TimeSpan.FromMilliseconds(Utils.GEOCOORDWATCHER_TIMEOUT)))
            {
                labelStatus.Text = Utils.GEOCOORDWATCHER_TIMEOUT_MSG;
            }
            else
            {
                labelStatus.Text = Utils.GEOCOORDWATCHER_START_MSG;
            }
            labelStatus.Text = labelStatus.Text + " - " + _watcher.Status.ToString();
            _controlSDValue = null;
            try
            {
                Control[] ctrls = ParentForm.Controls.Find(Utils.TXT_AVERAGE, true);
                foreach (Control c in ctrls)
                {
                    _controlSDValue = c;
                    break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, Utils.APP_CAPTION, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (_controlSDValue != null)
            {
                if (_sw == null)
                {
                    _sw = new StreamWriter(Application.StartupPath + "\\" + DateTime.Now.ToString("yyyyMMddHHmmss") +
                    "_" + _sdlogplugin.Frequency.ToString() + ".txt", true);
                    numericUpDownThresh.Enabled = false;
                    groupBoxOperator.Enabled = false;
                    buttonStart.Enabled = false;
                    buttonStop.Enabled = true;
                    timerSDLog.Enabled = true;
                }
            }
        }

        private void ButtonStop_Click(object sender, EventArgs e)
        {
            timerSDLog.Enabled = false;
            _watcher.Stop();
            labelStatus.Text = "";
            _sw.Close();
            _sw.Dispose();
            _sw = null;
            buttonStop.Enabled = false;
            buttonStart.Enabled = true;
            numericUpDownThresh.Enabled = true;
            groupBoxOperator.Enabled = true;
        }

        public void Close()
        {
            if (_sw != null)
            {
                _sw.Close();
            }
        }
        private void timerSDLog_Tick(object sender, EventArgs e)
        {
            decimal d;
            if (decimal.TryParse(_controlSDValue.Text.Replace("dB", "").Trim(), out d))
            {
                bool b = false;
                if (radioButtonLT.Checked)
                {
                    if (d < numericUpDownThresh.Value)
                    {
                        b = true;
                    }
                }
                else
                {
                    if (d > numericUpDownThresh.Value)
                    {
                        b = true;
                    }
                }
                if (b)
                {
                    _sw.WriteLine(string.Format("{0}\t{1}\t{2}\t{3}\t{4}", DateTime.Now.ToString("yyyyMMddHHmmss"), d, _sdlogplugin.Frequency, labelLat.Text, labelLon.Text));
                }
            }
        }

        private void watcher_StatusChanged(object sender, GeoPositionStatusChangedEventArgs e)
        {
            labelLat.Text = "";
            labelLon.Text = "";
            labelStatus.Text = "";
            switch (e.Status)
            {
                case GeoPositionStatus.Ready:
                    {
                        if (!_watcher.Position.Location.IsUnknown)
                        {
                            labelLat.Text = _watcher.Position.Location.Latitude.ToString();
                            labelLon.Text = _watcher.Position.Location.Longitude.ToString();
                        }
                        else
                        {
                            labelStatus.Text = Utils.STATUS_CANNOT_FIND_DATA;
                        }
                        break;
                    }
                case GeoPositionStatus.Initializing:
                    {
                        labelStatus.Text = Utils.STATUS_INIT;
                        break;
                    }
                case GeoPositionStatus.NoData:
                    {
                        labelStatus.Text = Utils.STATUS_NO_DATA;
                        break;
                    }
                case GeoPositionStatus.Disabled:
                    {
                        labelStatus.Text = Utils.STATUS_DISABLED;
                        break;
                    }
            }
        }

        //void watcher_PositionChanged(object sender, GeoPositionChangedEventArgs<GeoCoordinate> e)
        //{
        //    labelLat.Text = e.Position.Location.Latitude.ToString();
        //    labelLon.Text = e.Position.Location.Longitude.ToString();
        //}
    }
}
