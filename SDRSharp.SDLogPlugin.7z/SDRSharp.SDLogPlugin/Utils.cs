﻿using System.Reflection;
using System.Windows.Forms;
using System.Linq;

namespace SDRSharp.SDLogPlugin
{
    class Utils
    {
        public static string APP_CAPTION = "SDLog";
        public static string TXT_AVERAGE = "averageTextBox";
        public static string STATUS_INIT = "Location: working on location fix";
        public static string STATUS_NO_DATA = "Location: no data";
        public static string STATUS_DISABLED = "Location disabled";
        public static string STATUS_CANNOT_FIND_DATA = "Cannot find location data";
        public static string GEOCOORDWATCHER_TIMEOUT_MSG = "GeoCoordinateWatcher timed out on start";
        public static string GEOCOORDWATCHER_START_MSG = "GeoCoordinateWatcher started";
        public static int GEOCOORDWATCHER_TIMEOUT = 2000;
        public static string Version()
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            return assembly.GetName().Version.ToString();
        }
    }
}
